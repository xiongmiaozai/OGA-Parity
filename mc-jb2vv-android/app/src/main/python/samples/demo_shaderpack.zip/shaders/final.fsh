#version 330
out vec4 c; void main() { c = vec4(1.0); }
